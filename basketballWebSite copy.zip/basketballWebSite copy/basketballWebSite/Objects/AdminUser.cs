﻿using System;
namespace cs341.Tests.Controllers
{
    public class AdminUser
    {
        private String firstName;
        private String email;
        private int number;
        private String lastName;

        public AdminUser(String lN, String e, String fN, int num)
        {
            firstName = fN;
            lastName = lN;
            number = num;
            email = e;
        }
        public void addAdminUser(){
            
        }
        public void createEvent(){
            
        }
        public void deleteEvent(){
            
        }
        public void addProgramMangerUser(){
            
        }

        public void addVolunteer(){
            
        }

        public void deleteProgramManger(){
            
        }

        public void deleteVolunter(){
            
        }

    }
}
